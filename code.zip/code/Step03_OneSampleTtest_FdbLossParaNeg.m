%-----------------------------------------------------------------------
% Job saved on 20-Jul-2017 14:19:21 by cfg_util (rev $Rev: 6460 $)
% spm SPM - SPM12 (6470)
% cfg_basicio BasicIO - Unknown
%-----------------------------------------------------------------------
matlabbatch{1}.cfg_basicio.file_dir.dir_ops.cfg_mkdir.parent = {'F:\LP2\Ttest\Analysis1\Para5\'};
matlabbatch{1}.cfg_basicio.file_dir.dir_ops.cfg_mkdir.name = 'FdbLossParaNeg';
matlabbatch{2}.spm.stats.factorial_design.dir(1) = cfg_dep('Make Directory: Make Directory ''FdbLossParaNeg''', substruct('.','val', '{}',{1}, '.','val', '{}',{1}, '.','val', '{}',{1}, '.','val', '{}',{1}), substruct('.','dir'));
%%
matlabbatch{2}.spm.stats.factorial_design.des.t1.scans = {
                                                          'F:\LP2\ContrastData1_Para5\FdbLossParaNeg\Sub01.nii,1'
                                                          'F:\LP2\ContrastData1_Para5\FdbLossParaNeg\Sub02.nii,1'
                                                          'F:\LP2\ContrastData1_Para5\FdbLossParaNeg\Sub03.nii,1'
                                                          'F:\LP2\ContrastData1_Para5\FdbLossParaNeg\Sub04.nii,1'
                                                          'F:\LP2\ContrastData1_Para5\FdbLossParaNeg\Sub05.nii,1'
                                                          'F:\LP2\ContrastData1_Para5\FdbLossParaNeg\Sub06.nii,1'
                                                          'F:\LP2\ContrastData1_Para5\FdbLossParaNeg\Sub07.nii,1'
                                                          'F:\LP2\ContrastData1_Para5\FdbLossParaNeg\Sub08.nii,1'
                                                          'F:\LP2\ContrastData1_Para5\FdbLossParaNeg\Sub09.nii,1'
                                                          'F:\LP2\ContrastData1_Para5\FdbLossParaNeg\Sub10.nii,1'
                                                          'F:\LP2\ContrastData1_Para5\FdbLossParaNeg\Sub11.nii,1'
                                                          'F:\LP2\ContrastData1_Para5\FdbLossParaNeg\Sub12.nii,1'
                                                          'F:\LP2\ContrastData1_Para5\FdbLossParaNeg\Sub13.nii,1'
                                                          'F:\LP2\ContrastData1_Para5\FdbLossParaNeg\Sub14.nii,1'
                                                          'F:\LP2\ContrastData1_Para5\FdbLossParaNeg\Sub15.nii,1'
                                                          'F:\LP2\ContrastData1_Para5\FdbLossParaNeg\Sub16.nii,1'
                                                          'F:\LP2\ContrastData1_Para5\FdbLossParaNeg\Sub17.nii,1'
                                                          'F:\LP2\ContrastData1_Para5\FdbLossParaNeg\Sub18.nii,1'
                                                          'F:\LP2\ContrastData1_Para5\FdbLossParaNeg\Sub19.nii,1'
                                                          'F:\LP2\ContrastData1_Para5\FdbLossParaNeg\Sub20.nii,1'
                                                          'F:\LP2\ContrastData1_Para5\FdbLossParaNeg\Sub21.nii,1'
                                                          'F:\LP2\ContrastData1_Para5\FdbLossParaNeg\Sub22.nii,1'
                                                          'F:\LP2\ContrastData1_Para5\FdbLossParaNeg\Sub23.nii,1'
                                                          'F:\LP2\ContrastData1_Para5\FdbLossParaNeg\Sub24.nii,1'
                                                          'F:\LP2\ContrastData1_Para5\FdbLossParaNeg\Sub25.nii,1'
                                                          };
%%
matlabbatch{2}.spm.stats.factorial_design.cov = struct('c', {}, 'cname', {}, 'iCFI', {}, 'iCC', {});
matlabbatch{2}.spm.stats.factorial_design.multi_cov = struct('files', {}, 'iCFI', {}, 'iCC', {});
matlabbatch{2}.spm.stats.factorial_design.masking.tm.tm_none = 1;
matlabbatch{2}.spm.stats.factorial_design.masking.im = 0;
matlabbatch{2}.spm.stats.factorial_design.masking.em = {'E:\spm12\toolbox\FieldMap\brainmask.nii,1'};
matlabbatch{2}.spm.stats.factorial_design.globalc.g_omit = 1;
matlabbatch{2}.spm.stats.factorial_design.globalm.gmsca.gmsca_no = 1;
matlabbatch{2}.spm.stats.factorial_design.globalm.glonorm = 1;
matlabbatch{3}.spm.stats.fmri_est.spmmat(1) = cfg_dep('Factorial design specification: SPM.mat File', substruct('.','val', '{}',{2}, '.','val', '{}',{1}, '.','val', '{}',{1}), substruct('.','spmmat'));
matlabbatch{3}.spm.stats.fmri_est.write_residuals = 0;
matlabbatch{3}.spm.stats.fmri_est.method.Classical = 1;
matlabbatch{4}.spm.stats.con.spmmat(1) = cfg_dep('Model estimation: SPM.mat File', substruct('.','val', '{}',{3}, '.','val', '{}',{1}, '.','val', '{}',{1}), substruct('.','spmmat'));
matlabbatch{4}.spm.stats.con.consess{1}.tcon.name = 'Pos';
matlabbatch{4}.spm.stats.con.consess{1}.tcon.weights = 1;
matlabbatch{4}.spm.stats.con.consess{1}.tcon.sessrep = 'none';
matlabbatch{4}.spm.stats.con.consess{2}.tcon.name = 'Neg';
matlabbatch{4}.spm.stats.con.consess{2}.tcon.weights = -1;
matlabbatch{4}.spm.stats.con.consess{2}.tcon.sessrep = 'none';
matlabbatch{4}.spm.stats.con.delete = 0;
