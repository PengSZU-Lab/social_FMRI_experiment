% function PPPI_FSFAST_WRAPPER(subjectnos)
clear;clc;
ROIPath = 'F:\LP2\PENG_PPI\Roi_exp2';                             
DataPath = 'F:\LP2\Estimation1\Para5';        
Study_Dir = 'F:\LP2\PENG_PPI';                             
subnum=[25];
for i = 1: length(subnum) 
    Subjects{i,1}=['Sub',num2str(subnum(i),'%.2d')]; 
end


 regionname = {'Pride_1','Pride_2','Pride_3','Guilt_1','Conj_1','Conj_2','Conj_3'};


for ii=1:length(Subjects)
    for n = 1:length(regionname)
%         regionfile{n}=fullfile(ROIPath,Subjects{ii},[regionname{n},'_roi.img']);
        regionfile{n}=fullfile(ROIPath,[regionname{n},'_roi.img']);
    end
    try
        clear config 
    catch
    end
    
    config.Subject=Subjects{ii};
    config.Study=Study_Dir;
    config.Subject_Subdirectory='P';
    config.Model=''; % change for new model
    config.zip=1;
    
    try
        FSFAST2SPM(config)
    catch
        continue; %go to next subject
    end
    
%     for jj=1:numel(regionfile)
    for jj=1:length(regionname)
%     for jj=1:1
%         for mm=1:3
        %try
%             Directory=[Study_Dir filesep Subjects{ii} filesep config.Subject_Subdirectory filesep 'SPMana' filesep config.Model models{mm} ];
            Directory=[DataPath filesep Subjects{ii}];           
            load(fullfile(Study_Dir,'Batch','ppi_master_template_exp2.mat'));
            cd(Directory);
            P.subject=Subjects{ii};
            P.directory=Directory;
            P.VOI=regionfile{jj};
            P.Region=regionname{jj};
            P.FSFAST=1;
            P.FSFAST_source=[DataPath filesep Subjects{ii} filesep 'SPM.mat']; % subcortical iamge for ROI extraction
            P.wb=0; % may need to be changed to 0 on local computers
            P.concatR=1;
            save(fullfile(Study_Dir,'P',[Subjects{ii} '_analysis_' regionname{jj} '.mat']),'P');
            PPPI(fullfile(Study_Dir,'P',[Subjects{ii} '_analysis_' regionname{jj} '.mat']));

    end
    % You will want to zip the files here if P.zipfiles is not set to 1.
end

